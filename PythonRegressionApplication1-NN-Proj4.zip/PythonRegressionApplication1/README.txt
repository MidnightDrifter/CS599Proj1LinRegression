The only change of note is, instead of drawing a single line across / throughout the data, I instead
graphed the projected results from the testing data, and drew a line through those various points.
Pyplot was not cooperating or playing nicely with drawing the singular line.

Sean Higgins
CS 599
1-31-2018
Prof. Bede



Proj 2 - Naive Bayes
Success!  It all works--the only tweak I made was changing the spam-ham threshold to 0.7.